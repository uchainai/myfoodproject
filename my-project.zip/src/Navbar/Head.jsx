import React from "react";

function Head() {
  return <div></div>;
}

export default Head;

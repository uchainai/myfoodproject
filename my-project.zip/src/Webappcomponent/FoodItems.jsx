import React from "react";

function FoodItems() {
  return <div id="recipicontainer"></div>;
}

export default FoodItems;

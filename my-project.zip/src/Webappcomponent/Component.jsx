import React from "react";
import Searchbar from "./Searchbar";

function Component() {
  return (
    <div>
      <Searchbar />
    </div>
  );
}

export default Component;

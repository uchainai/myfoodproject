import React from "react";

function Login() {
  return (
    <div className="text-center bg-white h-screen ">
      <h1 className="text-3xl font-bold my-6 ">Register</h1>
      <div className=" flex   justify-center">
        <div className="grid grid-cols-3 gap-4 ">
          <button className="bg-green-600 my-auto  py-4 w-48  rounded-lg ">
            Student
          </button>
          <button className="bg-green-600 my-auto  py-4 w-48  rounded-lg">
            Document
          </button>
          <button className="bg-green-600 my-auto  py-4 w-48  rounded-lg">
            Registration
          </button>
          <button className="bg-green-600 my-auto  py-4 w-48  rounded-lg">
            hello
          </button>
          <button className="bg-green-600 my-auto  py-4 w-48   rounded-lg">
            hello
          </button>
          <button className="bg-green-600 my-auto  py-4 w-48  rounded-lg">
            hello
          </button>
          <button className="bg-green-600 my-auto  py-4 w-48  rounded-lg">
            hello
          </button>
          <button className="bg-green-600 my-auto  py-4 w-48  rounded-lg">
            hello
          </button>
          <button className="bg-green-600 my-auto  py-4 w-48  rounded-lg">
            hello
          </button>
          <button className="bg-green-600 my-auto  py-4 w-48   rounded-lg">
            hello
          </button>
        </div>
      </div>
    </div>
  );
}

export default Login;
